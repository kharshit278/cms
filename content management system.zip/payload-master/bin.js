#!/usr/bin/env node
require('./dist/bin');
