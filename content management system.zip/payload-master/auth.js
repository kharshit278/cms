module.exports = require('./dist/auth');
