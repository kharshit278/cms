exports.List = require('../../dist/admin/components/views/collections/List/Default').default;
