exports.Edit = require('../../dist/admin/components/views/collections/Edit/Default').default;
