exports.Cell = require('../../dist/admin/components/views/collections/List/Cell').default;
