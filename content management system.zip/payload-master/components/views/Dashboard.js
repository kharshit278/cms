exports.Dashboard = required('../../dist/admin/components/views/Dashboard/Default').default;
