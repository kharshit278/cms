export { default as Edit } from '../../dist/admin/components/views/collections/Edit/Default';
export type { Props } from '../../dist/admin/components/views/collections/Edit/types';
