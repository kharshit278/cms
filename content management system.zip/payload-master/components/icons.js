exports.Chevron = require('../dist/admin/components/icons/Chevron').default;
exports.X = require('../dist/admin/components/icons/X').default;
