exports.usePreferences = require('../dist/admin/components/utilities/Preferences').usePreferences;
