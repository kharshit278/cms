export { default as DefaultTemplate } from '../dist/admin/components/templates/Default';
export { default as MinimalTemplate } from '../dist/admin/components/templates/Minimal';
