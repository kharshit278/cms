exports.DefaultTemplate = require('../dist/admin/components/templates/Default').default;
exports.MinimalTemplate = require('../dist/admin/components/templates/Minimal').default;