export type { Props } from '../../dist/admin/components/forms/field-types/RichText/types';
