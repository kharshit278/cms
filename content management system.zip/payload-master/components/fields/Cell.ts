export type { Props } from '../../dist/admin/components/views/collections/List/Cell/types';
