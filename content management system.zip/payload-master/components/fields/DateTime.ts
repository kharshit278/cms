export type { Props } from '../../dist/admin/components/forms/field-types/DateTime/types';
