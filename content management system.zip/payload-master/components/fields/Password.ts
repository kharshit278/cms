export type { Props } from '../../dist/admin/components/forms/field-types/Password/types';
