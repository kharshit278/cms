exports.Meta = require('../dist/admin/components/utilities/Meta').default;
exports.useLocale = require('../dist/admin/components/utilities/Locale').useLocale;
exports.useDocumentInfo = require('../dist/admin/components/utilities/DocumentInfo').useDocumentInfo;
exports.useConfig = require('../dist/admin/components/utilities/Config').useConfig;
exports.useAuth = require('../dist/admin/components/utilities/Auth').useAuth;
exports.useEditDepth = require('../dist/admin/components/utilities/EditDepth').useEditDepth;
exports.useTheme = require('../dist/admin/components/utilities/Theme').useTheme;
