exports.buildConfig = require('./dist/config/build').buildConfig;
