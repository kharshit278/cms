module.exports = {
  root: true,
  extends: ['plugin:@next/next/recommended', '@payloadcms'],
}
