module.exports = {
  root: true,
  extends: ['@payloadcms'],
}
