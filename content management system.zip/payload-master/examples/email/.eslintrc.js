module.exports = {
  root: true,
  extends: ['@payloadcms'],
  rules: {
    '@typescript-eslint/no-unused-vars': 'warn',
  },
}
